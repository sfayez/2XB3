/*
 * Student Information
 ----------------------------------
 Student Name: Fayez, Susan
 Student Number: 001404420
 Course Code: CS/SE 2XB3
 Lab Section: 03

 I attest that the following code being submitted is my own individual work
 */
package cas.xb3.A1Package;

import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;

/**
 * Class creates a tester for the dictionary ADT.
 */
public class TestDictionary {

    /**
     * Main method runs all the testing methods. Uses print writer to clear the
     * output.txt file before running the test methods
     *
     * @param args command line arguments, doesn't apply for this function
     */
    public static void main(String[] args) {
        try {
            PrintWriter clear = new PrintWriter("src/cas/xb3/A1Package/output.txt");
            clear.print("");
            clear.close();
        } catch (Exception e) {
            System.out.println("Couldn't open file");
        }

        testInsert();
        testGetValue();
        testGetKey();
        testRemove();
        testCompare();
        testContains();
        testCount();
        testIsEmpty();
        testPrintKeys();
    }

    /**
     * Method initializes and inserts values into a dictionary for test methods
     * to use. Reads the pairs from the input.txt file and places them in a
     * dictionary, removing brackets and commas.
     *
     * @return testDict A dictionary ADT with 20 entries
     */
    public static Dictionary testStart() {
        Dictionary testDict = new Dictionary();

        try {
            Scanner read = new Scanner(new File("src/cas/xb3/A1Package/input.txt"));

            while (read.hasNext()) {
                String x = read.next();
                x = x.replaceAll("[\\( \\) ,]", "");
                String y = read.next();
                y = y.replaceAll("[\\( \\) ,]", "");
                try {
                    testDict.insert(Integer.parseInt(x), y);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter an integer");
                }
            }
            read.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Couldn't open file");
        }

        return testDict;
    }

    /**
     * Method tests if insert() works properly. Prints the start message to
     * output.txt and calls the testStart() method to initialize a dictionary.
     * Creates results array lists for keys an values based on what the contents
     * of the dictionary should be and compares the contents of test dictionary
     * and the results array list. If they are equal pass message is written to
     * output.txt, if not fail message is wrtitten to output.txt. Method
     * completion message written to output.txt
     */
    public static void testInsert() {
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("Entering testInsert...");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }

        Dictionary testDict = testStart();

        ArrayList keysResult = new ArrayList();
        ArrayList valuesResult = new ArrayList();

        valuesResult.add("hi");
        valuesResult.add("this");
        valuesResult.add("that");
        valuesResult.add("75");
        valuesResult.add("cat");
        valuesResult.add("dog");
        valuesResult.add("no");
        valuesResult.add("hi");
        valuesResult.add("yes");
        valuesResult.add("cake");
        valuesResult.add("class");
        valuesResult.add("car");
        valuesResult.add("hi");
        valuesResult.add("food");
        valuesResult.add("outside");
        valuesResult.add("hot");
        valuesResult.add("sweet");
        valuesResult.add("time");
        valuesResult.add("hi");
        valuesResult.add("yes");

        keysResult.add(1);
        keysResult.add(2);
        keysResult.add(3);
        keysResult.add(4);
        keysResult.add(5);
        keysResult.add(6);
        keysResult.add(7);
        keysResult.add(8);
        keysResult.add(9);
        keysResult.add(10);
        keysResult.add(11);
        keysResult.add(12);
        keysResult.add(13);
        keysResult.add(14);
        keysResult.add(15);
        keysResult.add(16);
        keysResult.add(17);
        keysResult.add(18);
        keysResult.add(19);
        keysResult.add(20);

        boolean check = false;
        for (int i = 0; i < 20; i++) {
            String one = (String) testDict.values.get(i);
            String two = (String) valuesResult.get(i);
            if (testDict.keys.get(i) == keysResult.get(i) && one.equals(two)) {
                check = true;
            } else {
                check = false;
                break;
            }
        }
        if (check) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Insert test passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        } else {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Insert test failed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("testInsert completed.");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }
    }

    /**
     * Method checks whether getValue() works properly. Prints the start message
     * to output.txt and calls the testStart() method to initialize a
     * dictionary. getValue() method called for three test cases: one in the
     * dictionary and two not in the dictionary (one with a negative key).
     * Values from test cases compared to expected results. If they pass, pass
     * messages written to output.txt. If they fail, fail message written to
     * output.txt. Completion message written to to output.txt
     */
    public static void testGetValue() {
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("Entering testGetValue...");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }

        Dictionary testDict = testStart();

        String testOne = testDict.getValue(5);
        String testTwo = testDict.getValue(50);
        String testThree = testDict.getValue(-3);

        if (testOne.equals("cat")) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case one passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        if (testTwo.equals("")) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case two passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        if (testThree.equals("")) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case three passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        } else {
            if (testOne.equals("cat")) {
                try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                        BufferedWriter bw = new BufferedWriter(fw);
                        PrintWriter out = new PrintWriter(bw)) {
                    out.println("Test cases failed.");
                    bw.close();
                } catch (IOException e) {
                    System.out.println("Couldn't open file");
                }
            }
        }
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("getValueTest completed.");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }

    }

    /**
     * Method tests whether getKey() works properly. Prints the start message to
     * output.txt and calls the testStart() method to initialize a dictionary.
     * Creates three test cases: a value with multiple occurrences in the
     * dictionary, a value with no occurrences, and a value with one occurrence.
     * Compares output of getKey() to expected results. If the test cases pass,
     * pass message is written to output.txt. If they fail, fail message is
     * written to output.txt. Completion message is written to output.txt.
     */
    public static void testGetKey() {
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("Entering testGetKey...");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }

        Dictionary testDict = testStart();

        ArrayList testOne = testDict.getKey("hi");
        ArrayList testTwo = testDict.getKey("heck");
        ArrayList testThree = testDict.getKey("car");

        ArrayList resultOne = new ArrayList();
        ArrayList resultTwo = new ArrayList();
        ArrayList resultThree = new ArrayList();

        resultOne.add(1);
        resultOne.add(8);
        resultOne.add(13);
        resultOne.add(19);

        resultThree.add(12);

        boolean checkOne = false;
        boolean checkTwo = false;
        boolean checkThree = false;

        for (int i = 0; i < testOne.size(); i++) {
            if (testOne.get(i) == resultOne.get(i)) {
                checkOne = true;
            } else {
                checkOne = false;
                break;
            }
        }

        if (testTwo.isEmpty() && resultTwo.isEmpty()) {
            checkTwo = true;
        }

        for (int i = 0; i < testThree.size(); i++) {
            if (testThree.get(i) == resultThree.get(i)) {
                checkThree = true;
            } else {
                checkThree = false;
                break;
            }
        }
        if (checkOne) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case one passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        if (checkTwo) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case two passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        if (checkThree) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case Three passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        } else {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test cases failed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("testGetKeys complete.");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }
    }

    /**
     * Method that checks whether remove() works properly. Prints the start
     * message to output.txt and calls the testStart() method to initialize a
     * dictionary. Creates four test cases to remove from the dictionary: a key
     * and value that exist in the dictionary and correspond to each other, a
     * key and value that don't exist in the dictionary, a key that doesn't
     * exist but a value that does, and a key and value that exist in the
     * dictionary but don't correspond to each other. The contents of the
     * dictionary are checked against what we expect them to be (only removing
     * the first test case). If it passes, the pass message is written to
     * output.txt, if it fails the fail message is printed to output.txt. The
     * completion message is written to output.txt.
     */
    public static void testRemove() {
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("Entering testRemove...");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }

        Dictionary testDict = testStart();

        testDict.remove(3, "that");
        testDict.remove(51, "mess");
        testDict.remove(30, "hi");
        testDict.remove(5, "get");

        ArrayList keysResult = new ArrayList();
        ArrayList valuesResult = new ArrayList();

        valuesResult.add("hi");
        valuesResult.add("this");
        valuesResult.add("75");
        valuesResult.add("cat");
        valuesResult.add("dog");
        valuesResult.add("no");
        valuesResult.add("hi");
        valuesResult.add("yes");
        valuesResult.add("cake");
        valuesResult.add("class");
        valuesResult.add("car");
        valuesResult.add("hi");
        valuesResult.add("food");
        valuesResult.add("outside");
        valuesResult.add("hot");
        valuesResult.add("sweet");
        valuesResult.add("time");
        valuesResult.add("hi");
        valuesResult.add("yes");

        keysResult.add(1);
        keysResult.add(2);
        keysResult.add(4);
        keysResult.add(5);
        keysResult.add(6);
        keysResult.add(7);
        keysResult.add(8);
        keysResult.add(9);
        keysResult.add(10);
        keysResult.add(11);
        keysResult.add(12);
        keysResult.add(13);
        keysResult.add(14);
        keysResult.add(15);
        keysResult.add(16);
        keysResult.add(17);
        keysResult.add(18);
        keysResult.add(19);
        keysResult.add(20);

        boolean check = false;
        for (int i = 0; i < 19; i++) {
            String one = (String) testDict.values.get(i);
            String two = (String) valuesResult.get(i);
            if (testDict.keys.get(i) == keysResult.get(i) && one.equals(two)) {
                check = true;
            } else {
                check = false;
                break;
            }
        }
        if (check) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Remove test passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        } else {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Remove test failed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("testRemove complete.");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }

    }

    /**
     * Method that checks whether compare() works properly. Prints the start
     * message to output.txt and calls the testStart() method to initialize a
     * dictionary. Four test cases are created: two keys that exist and refer to
     * the same value, two keys that exist and refer to different values, a key
     * that exists and a key that does not, and two keys that do not exist.
     * Checks if the boolean values are what we expect them to be (the first is
     * true and the rest are false). If the test is passed, the pass message is
     * written to output.txt, if they fail, the fail message is written to
     * output.txt. The completion message is written to output.txt.
     */
    public static void testCompare() {
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("Entering testCompare...");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }

        Dictionary testDict = testStart();

        boolean testOne = testDict.compare(1, 19);
        boolean testTwo = testDict.compare(1, 4);
        boolean testThree = testDict.compare(0, 9);
        boolean testFour = testDict.compare(72, -5);

        if (testOne) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case one passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        if (!testTwo) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case two passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        if (!testThree) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case three passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        if (!testFour) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case four passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        } else {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test cases failed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("testCompare completed");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }
    }

    /**
     * Method that checks whether contains() works properly. Prints the start
     * message to output.txt and calls the testStart() method to initialize a
     * dictionary. Three test cases are created: a key that exists in the
     * dictionary, a key that does not, and a neagtive key that does not. The
     * boolean values are tested against what we expect them to be (the first
     * case true ad the others false). If the test is passed the pass message is
     * written to output.txt, if it fails the fail message is written to
     * output.txt. The completion message is written to output.txt
     */
    public static void testContains() {
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("Entering testContains...");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }

        Dictionary testDict = testStart();

        boolean testOne = testDict.contains(15);
        boolean testTwo = testDict.contains(629);
        boolean testThree = testDict.contains(-4);

        if (testOne) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case one passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        if (!testTwo) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case two passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        if (!testThree) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case three passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        } else {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test cases failed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("testContains completed.");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }

    }

    /**
     * Method that checks whether count() works properly. Prints the start
     * message to output.txt and calls the testStart() method to initialize a
     * dictionary. Two test cases are created: A dictionary with elements in it,
     * and an empty dictionary. Checks if count() returns the number of elements
     * we expect. If the test is passed, the pass message is written to
     * output.txt, if it fails the fail message is written to output.txt. The
     * completion message is written to output.txt.
     */
    public static void testCount() {
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("Entering testCount...");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }

        Dictionary testDictOne = testStart();
        Dictionary testDictTwo = new Dictionary();

        int sizeOne = testDictOne.count();
        int sizeTwo = testDictTwo.count();

        if (sizeOne == 20) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case one passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        if (sizeTwo == 0) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case two passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        } else {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test cases failed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("testCount completed.");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }

    }

    /**
     * Method that checks whether isEmpty() works properly. Prints the start
     * message to output.txt and calls the testStart() method to initialize a
     * dictionary. Creates two test cases: A dictionary with elements and an
     * empty dictionary. The boolean values are checked against what we expect
     * them to be. If the test passed the pass message is written to output.txt.
     * If it fails, the fails message is wirtten to output.txt The completion
     * message is written to output.txt
     */
    public static void testIsEmpty() {
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("Entering testIsEmpty...");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }

        Dictionary testDictOne = testStart();
        Dictionary testDictTwo = new Dictionary();

        boolean testOne = testDictOne.isEmpty();
        boolean testTwo = testDictTwo.isEmpty();

        if (!testOne) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case one passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        if (testTwo) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case two passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        } else {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test cases failed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("testIsEmpty complete.");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }
    }

    /**
     * Method that checks whether printKeys() works properly. Prints the start
     * message to output.txt and calls the testStart() method to initialize a
     * dictionary. Two test cases are created: A dictionary with elements in it
     * and an empty dictionary. The output strings are checked against the
     * expected result. If the test is passed, the pass message is written to
     * output.txt, if it fails the fail message is written to output.txt. The
     * completion message is written to output.txt
     */
    public static void testPrintKeys() {
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("Entering testPrintKeys...");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }

        Dictionary testDictOne = testStart();
        Dictionary testDictTwo = new Dictionary();

        String testOne = testDictOne.printKeys();
        String testTwo = testDictTwo.printKeys();

        String resultOne = "{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20}";
        String resultTwo = "{}";

        if (testOne.equals(resultOne)) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case one passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        if (testTwo.equals(resultTwo)) {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test case two passed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        } else {
            try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                out.println("Test cases failed.");
                bw.close();
            } catch (IOException e) {
                System.out.println("Couldn't open file");
            }
        }
        try (FileWriter fw = new FileWriter("src/cas/xb3/A1Package/output.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)) {
            out.println("testPrintKeys complete.");
            bw.close();
        } catch (IOException e) {
            System.out.println("Couldn't open file");
        }
    }

}
/**
 * SOURCES:
 * http://stackoverflow.com/questions/6994518/how-to-delete-the-content-of-text-file-without-deleting-itself
 * http://stackoverflow.com/questions/1625234/how-to-append-text-to-an-existing-file-in-java
 * http://stackoverflow.com/questions/4430112/how-do-i-remove-some-characters-from-my-string
 */
