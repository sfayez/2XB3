/*
 * Student Information
 ----------------------------------
 Student Name: Fayez, Susan
 Student Number: 001404420
 Course Code: CS/SE 2XB3
 Lab Section: 03

 I attest that the following code being submitted is my own individual work
 */
package cas.xb3.A1Package;

import java.util.ArrayList;
import java.util.Objects;
import java.util.HashSet;
import java.util.Set;

/**
 * Class creates a dictionary ADT. The dictionary consists of two array lists
 * keys and values. Each key is unique and has a corresponding value
 */
public class Dictionary {

    /**
     * Initializing the global variables for the dictionary
     */
    protected final ArrayList keys;
    protected final ArrayList values;

    /**
     * Default constructor initializes an empty dictionary
     */
    public Dictionary() {
        this.keys = new ArrayList();
        this.values = new ArrayList();
    }

    /**
     * Constructor for dictionary if user already has array lists for keys and
     * values initiated. Prints warnings if user tries to enter array lists of
     * different sizes, of sizes greater than 20, or if there are any repeated
     * numbers in the keys array list. Empty dictionary initialized in these
     * cases. If the array lists pass the tests, entered array lists are
     * initialized as keys and values and the dictionary is created.
     *
     * @param keys array list containing the keys
     * @param values array list containing the values
     */
    public Dictionary(ArrayList keys, ArrayList values) {
        Set<Integer> set = new HashSet<>(keys);
        if (set.size() < keys.size()) {
            System.out.println("Keys must be unique. Empty dictionary initialized");
            this.keys = new ArrayList();
            this.values = new ArrayList();
        } else if (keys.size() > 20 || values.size() > 20) {
            System.out.println("The maximum size of the dictionary is 20 elements. Empty dictionary initialized");
            this.keys = new ArrayList();
            this.values = new ArrayList();
        } else if (keys.size() != values.size()) {
            System.out.println("Keys arraylist and values arraylist must be the same size. Empty dictionary initialized");
            this.keys = new ArrayList();
            this.values = new ArrayList();
        } else {
            this.keys = keys;
            this.values = values;
        }

    }

    /**
     * Method to insert words and corresponding keys into the dictionary. Checks
     * whether or not the desired key is in the keys array list already. If it
     * is, error message is printed. If it is not, checks whether the size of
     * the dictionary is at 20 items yet. If it is, error message is printed. If
     * it is not, the key and the value are added to the dictionary.
     *
     * @param key integer to correspond to the entered word we wish to add to
     * the dictionary
     * @param value word we wish to add to the dictionary
     */
    public void insert(int key, String value) {
        boolean check = false;

        for (Object key1 : this.keys) {
            if (key == (Integer) key1) {
                check = true;
                break;
            }
        }
        if (!check) {
            if (this.keys.size() < 20 && this.values.size() < 20) {
                this.keys.add(key);
                this.values.add(value);
            } else {
                System.out.println("The dictionary is full");
            }
        } else {
            System.out.println("This word is already in the dictionary");
        }
    }

    /**
     * Method that returns the word corresponding to the entered key. Checks
     * whether the key is in the dictionary and records the array index if it
     * is. If it isn't, error message is printed. If the test is passed, the
     * value at the recorded array index is returned
     *
     * @param key integer that corresponds to the word we want to get
     * @return the word that corresponds to the entered key. If the key doesn't
     * exist in the library, empty string returned
     */
    public String getValue(int key) {
        boolean check = false;
        int count = 0;
        String value = "";

        for (Object key1 : this.keys) {
            if (key == (Integer) key1) {
                check = true;
                break;
            } else {
                count++;
            }
        }
        if (check) {
            value = (String) this.values.get(count);
        } else {
            System.out.println("This key does not exist, no corresponding word in the dictionary. Empty string returned.");
        }
        return value;
    }

    /**
     * Method that returns array list containing all the keys to the given word.
     * Checks whether value is in the dictionary and records all array indices
     * of occurrences in an array list If there is at least one instance of
     * value in the dictionary, the keys with array indices that correspond to
     * value are returned in an array list If value is not in the dictionary,
     * error message is displayed
     *
     * @param value the word for which we want to find the keys of
     * @return an array list containing the keys corresponding to value. If
     * value is not in the dictionary, empty array list is returned
     */
    public ArrayList getKey(String value) {
        boolean check = false;
        int countOne = 0;
        ArrayList countTwo = new ArrayList();
        ArrayList result = new ArrayList();

        for (Object value1 : this.values) {
            if (value.equals((String) value1)) {
                check = true;
                countTwo.add(countOne);
            }
            countOne++;
        }
        if (check) {
            for (int i = 0; i < (Integer) countTwo.size(); i++) {
                int get = (Integer) countTwo.get(i);
                result.add((Integer) this.keys.get(get));
            }
        }
        return result;
    }

    /**
     * Method that removes words and their corresponding keys from the
     * dictionary. Checks if the entered key exists in the dictionary then
     * checks if the entered value exists in the dictionary with the same array
     * index If all checks are passed, they key and value are removed from the
     * dictionary. If any check fails, error messages are printed.
     *
     * @param key the key of the word we wish to remove from the dictionary
     * @param value the word we wish to remove from the dictionary
     */
    public void remove(int key, String value) {
        boolean checkOne = false;
        boolean checkTwo = false;
        int countOne = 0;
        int countTwo = 0;

        for (Object key1 : this.keys) {
            if ((Integer) key1 == key) {
                checkOne = true;
                break;
            } else {
                countOne++;
            }
        }
        for (Object value1 : this.values) {
            if (value.equals((String) value1) && countOne == countTwo) {
                checkTwo = true;
                break;
            } else {
                countTwo++;
            }
        }
        if (checkOne && checkTwo && (countOne == countTwo)) {
            System.out.println("Removing " + this.keys.get(countOne));
            System.out.println("Removing " + this.values.get(countTwo));
            this.keys.remove(countOne);
            this.values.remove(countTwo);
        }
        if (!checkOne) {
            System.out.println("Entered key does not exist");
        }
        if (!checkTwo) {
            System.out.println("Entered value does not match the key. No items removed from the dictionary.");
        } else {
            System.out.println("Entered key and value do not match. No items removed from the dictionary");
        }

    }

    /**
     * Method that checks if two keys correspond to the same word in the
     * dictionary. Checks if the keys are in the dictionary and records they
     * indices of the keys if they are. If one or both aren't in the dictionary,
     * error message is displayed. Checks if the
     *
     * @param keyOne key we wish to compare to the other to see if they refer to
     * the same word
     * @param keyTwo key we wish to compare to the other to see if they refer to
     * the same word
     * @return True if the keys refer to the same word, false if they do not or
     * one or both of the keys aren't in the dictionary
     */
    public boolean compare(int keyOne, int keyTwo) {
        boolean checkOne = false;
        boolean checkTwo = false;
        boolean checkThree = false;
        int countOne = 0;
        int countTwo = 0;

        for (Object key : this.keys) {
            if (keyOne == (Integer) key) {
                checkOne = true;
                break;
            } else {
                countOne++;
            }
        }
        for (Object key : this.keys) {
            if (keyTwo == (Integer) key) {
                checkTwo = true;
                break;
            } else {
                countTwo++;
            }
        }
        if (checkOne && checkTwo) {
            if (Objects.equals((String) this.values.get(countOne), (String) this.values.get(countTwo))) {
                checkThree = true;
            }
        }
        if (!checkOne) {
            System.out.println("Key one not in the dictionary");
        }
        if (!checkTwo) {
            System.out.println("Key two not in the dictionary");
        }
        return checkThree;
    }

    /**
     * Method checks whether or not input key is in the dictionary. Uses for
     * loop to check whether or not key is in the keys array list.
     *
     * @param key key we wish to check if it is in the dictionary
     * @return true if the key is in the dictionary, false if it is not.
     */
    public boolean contains(int key) {
        boolean check = false;
        for (Object key1 : this.keys) {
            if ((Integer) key1 == key) {
                check = true;
                break;
            }
        }
        if (check) {
            System.out.println("Entered key exists in the dictionary");
        } else {
            System.out.println("Entered key does not exist in the dictionary");
        }
        return check;
    }

    /**
     * Method that counts the size of the dictionary. Counts the number of keys
     * in the dictionary and the number of values in the dictionary. If the
     * numbers are not equal, warning printed
     *
     * @return counterOne The number of keys in the dictionary
     */
    public int count() {
        int counterOne = 0;
        int counterTwo = 0;

        for (Object key : this.keys) {
            counterOne++;
        }

        for (Object value : this.values) {
            counterTwo++;
        }

        if (counterOne > counterTwo) {
            System.out.println("Error: more keys than words in the dictionary. Number of keys returned");
        }
        if (counterOne < counterTwo) {
            System.out.println("Error: more words than keys in the dictionary. Number of keys returned");
        }
        return counterOne;
    }

    /**
     * Method that checks whether or not the dictionary is empty. Checks whether
     * or not the dictionary is empty, message printed
     *
     * @return check True if the dictionary is empty, false if it isn't.
     */
    public boolean isEmpty() {
        boolean check = false;
        if (this.keys.isEmpty() && this.values.isEmpty()) {
            System.out.println("The dictionary is empty");
            check = true;
        } else {
            System.out.println("The dictionary is not empty");
        }
        return check;
    }

    /**
     * Method that prints the keys of the dictionary. Converts the keys array
     * list to a string and takes the substring that removes the square
     * brackets. Appending curly brackets to the substring and printing the
     * result
     *
     * @return keyPrint The keys of the dictionary surrounded by curly brackets
     */
    public String printKeys() {
        String printer = this.keys.toString();
        int size = printer.length() - 1;

        printer = printer.substring(1, size);
        String keyPrint = "{" + printer + "}";

        System.out.println(keyPrint);
        return keyPrint;
    }
}
/**
 * SOURCES:
 * http://stackoverflow.com/questions/562894/java-detect-duplicates-in-arraylist
 * http://stackoverflow.com/questions/1809093/how-can-i-place-validating-constraints-on-my-method-input-parameters
 * http://stackoverflow.com/questions/4389480/print-array-without-brackets-and-commas
 */
