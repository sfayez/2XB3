/*
 * Student Information
 ----------------------------------
 Student Name: Fayez, Susan
 Student Number: 001404420
 Course Code: CS/SE 2XB3
 Lab Section: 03

 I attest that the following code being submitted is my own individual work
 */
package tests;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import sort.Heap;
import sort.Insertion;
import sort.Job;
import sort.Merge;


/**
 * Class runs experiments on the sorting algorithms
 * 
 * @author Susan Fayez
 *
 */
public class Experiments {
	/**
	 * Initializing the global variables for the experiments
	 */
	private static Job[] j1;
	private static Job[] j2;
	private static Job[] j3;
	private static Job[] j4;
	private static Job[] j5;
	private static Job[] j6;
	private static Job[] j7;
	private static Job[] j8;

	/**
	 * Finds the time to run sortInsert()
	 * @param x - The array whose sorting is to be timed
	 * @return - The time it takes to sort x
	 */
	private static double runSortInsert(Job[] x) {
		Stopwatch stopwatch = new Stopwatch();

		double startTime = stopwatch.elapsedTime();
		Insertion.sortInsert(x);
		double endTime = stopwatch.elapsedTime();
		return endTime - startTime;

	}
	
	/**
	 * Finds the time to run sortComparable()
	 * @param x - The array whose sorting is to be timed
	 * @return - The time it takes to sort x
	 */
	private static double runSortComparable(Job[] x) {
		Stopwatch stopwatch = new Stopwatch();
		double startTime = stopwatch.elapsedTime();
		Insertion.sortComparable(x, x.length);
		double endTime = stopwatch.elapsedTime();
		return endTime - startTime;

	}

	/**
	 * Finds the time to run sortBinary()
	 * @param x - The array whose sorting is to be timed
	 * @return - The time it takes to sort x
	 */
	private static double runSortBinary(Job[] x) {
		Stopwatch stopwatch = new Stopwatch();

		double startTime = stopwatch.elapsedTime();
		Insertion.sortBinary(x, x.length);
		double endTime = stopwatch.elapsedTime();
		return endTime - startTime;

	}

	/**
	 * Finds the time to run sortMerge()
	 * @param x - The array whose sorting is to be timed
	 * @return - The time it takes to sort x
	 */
	private static double runSortMerge(Job[] x) {
		Stopwatch stopwatch = new Stopwatch();

		double startTime = stopwatch.elapsedTime();
		Comparable[] s = Merge.sortMerge(x, x.length);
		double endTime = stopwatch.elapsedTime();
		return endTime - startTime;

	}

	/**
	 * Finds the time to run sortHeap()
	 * @param x - The array whose sorting is to be timed
	 * @return - The time it takes to sort x
	 */
	private static double runSortHeap(Job[] x) {
		Stopwatch stopwatch = new Stopwatch();

		double startTime = stopwatch.elapsedTime();
		Heap.sortHeap(x, x.length);
		double endTime = stopwatch.elapsedTime();
		return endTime - startTime;

	}

	/**
	 * running the experiments
	 * @param args command line arguments (N/A)
	 */
	public static void main(String[] args) {

		j1 = new Job[(int) Math.pow(2, 4)];
		j2 = new Job[(int) Math.pow(2, 6)];
		j3 = new Job[(int) Math.pow(2, 8)];
		j4 = new Job[(int) Math.pow(2, 10)];
		j5 = new Job[(int) Math.pow(2, 12)];
		j6 = new Job[(int) Math.pow(2, 14)];
		j7 = new Job[(int) Math.pow(2, 16)];
		j8 = new Job[(int) Math.pow(2, 18)];

		try {
			Scanner read = new Scanner(new File("data/a2_in.txt"));
			String text = "";
			int count1 = 0;
			while (read.hasNext()) {
				String x = read.next();
				x = x.replaceAll("[\\{ \\} ,]", " ");
				text = text + x;
				count1++;
			}
			String[] words = text.split("\\s+");

			int count2 = 1;
			for (int i = 0; i < Math.pow(2, 4); i++) {
				j1[i] = new Job(words[count2], Integer.parseInt(words[count2 + 1]),
						Integer.parseInt(words[count2 + 2]));
				count2 = count2 + 3;
			}

			for (int i = 0; i < Math.pow(2, 6); i++) {
				j2[i] = new Job(words[count2], Integer.parseInt(words[count2 + 1]),
						Integer.parseInt(words[count2 + 2]));
				count2 = count2 + 3;
			}

			for (int i = 0; i < Math.pow(2, 8); i++) {
				j3[i] = new Job(words[count2], Integer.parseInt(words[count2 + 1]),
						Integer.parseInt(words[count2 + 2]));
				count2 = count2 + 3;
			}

			for (int i = 0; i < Math.pow(2, 10); i++) {
				j4[i] = new Job(words[count2], Integer.parseInt(words[count2 + 1]),
						Integer.parseInt(words[count2 + 2]));
				count2 = count2 + 3;
			}

			for (int i = 0; i < Math.pow(2, 12); i++) {
				j5[i] = new Job(words[count2], Integer.parseInt(words[count2 + 1]),
						Integer.parseInt(words[count2 + 2]));
				count2 = count2 + 3;
			}

			for (int i = 0; i < Math.pow(2, 14); i++) {
				j6[i] = new Job(words[count2], Integer.parseInt(words[count2 + 1]),
						Integer.parseInt(words[count2 + 2]));
				count2 = count2 + 3;
			}

			for (int i = 0; i < Math.pow(2, 16); i++) {
				j7[i] = new Job(words[count2], Integer.parseInt(words[count2 + 1]),
						Integer.parseInt(words[count2 + 2]));
				count2 = count2 + 3;
			}

			for (int i = 0; i < Math.pow(2, 18); i++) {
				j8[i] = new Job(words[count2], Integer.parseInt(words[count2 + 1]),
						Integer.parseInt(words[count2 + 2]));
				count2 = count2 + 3;
			}

			read.close();
		} catch (FileNotFoundException ex) {
			System.out.println("Couldn't open file");
		}
		//Placing all of the Jobs from the inpu file into their appropriate arrays

		double i1 = runSortInsert(j1);
		double i2 = runSortInsert(j2);
		double i3 = runSortInsert(j3);
		double i4 = runSortInsert(j4);
		double i5 = runSortInsert(j5);

		double c1 = runSortComparable(j1);
		double c2 = runSortComparable(j2);
		double c3 = runSortComparable(j3);
		double c4 = runSortComparable(j4);
		double c5 = runSortComparable(j5);

		double b1 = runSortBinary(j1);
		double b2 = runSortBinary(j2);
		double b3 = runSortBinary(j3);
		double b4 = runSortBinary(j4);
		double b5 = runSortBinary(j5);

		double m1 = runSortMerge(j1);
		double m2 = runSortMerge(j2);
		double m3 = runSortMerge(j3);
		double m4 = runSortMerge(j4);
		double m5 = runSortMerge(j5);

		double h1 = runSortHeap(j1);
		double h2 = runSortHeap(j2);
		double h3 = runSortHeap(j3);
		double h4 = runSortHeap(j4);
		double h5 = runSortHeap(j5);
		
		//getting the times to run each sort

		try {
			PrintWriter clear = new PrintWriter("data/a2_analysis.txt");
			clear.print("");
			clear.close();
		} catch (Exception e) {
			System.out.println("Couldn't open file");
		}
		//clearing the output file

		try (FileWriter fw = new FileWriter("data/a2_analysis.txt", true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter out = new PrintWriter(bw)) {
			out.println("Dataset Size \t Sorting Algorithm \t \tExecution Time");

			out.println("---------------------------------------------------------------");

			out.println("2^4 \t \t \t sortInsert \t \t \t" + i1);
			out.println("2^6 \t \t \t sortInsert \t \t \t" + i2);
			out.println("2^8 \t \t \t sortInsert \t \t \t" + i3);
			out.println("2^10 \t \t \t sortInsert \t \t \t" + i4);
			out.println("2^12 \t \t \t sortInsert \t \t \t" + i5);

			out.println("2^4 \t \t \t sortComparable \t \t" + c1);
			out.println("2^6 \t \t \t sortComparable \t \t" + c2);
			out.println("2^8 \t \t \t sortComparable \t \t" + c3);
			out.println("2^10 \t \t \t sortComparable \t \t" + c4);
			out.println("2^12 \t \t \t sortComparable \t \t" + c5);

			out.println("2^4 \t \t \t sortBinary \t \t \t" + b1);
			out.println("2^6 \t \t \t sortBinary \t \t \t" + b2);
			out.println("2^8 \t \t \t sortBinary \t \t \t" + b3);
			out.println("2^10 \t \t \t sortBinary \t \t \t" + b4);
			out.println("2^12 \t \t \t sortBinary \t \t \t" + b5);

			out.println("2^4 \t \t \t sortMerge \t \t \t \t" + m1);
			out.println("2^6 \t \t \t sortMerge \t \t \t \t" + m2);
			out.println("2^8 \t \t \t sortMerge \t \t \t \t" + m3);
			out.println("2^10 \t \t \t sortMerge \t \t \t \t" + m4);
			out.println("2^12 \t \t \t sortMerge \t \t \t \t" + m5);

			out.println("2^4 \t \t \t sortHeap \t \t \t \t" + h1);
			out.println("2^6 \t \t \t sortHeap \t \t \t \t" + h2);
			out.println("2^8 \t \t \t sortHeap \t \t \t \t" + h3);
			out.println("2^10 \t \t \t sortHeap \t \t \t \t" + h4);
			out.println("2^12 \t \t \t sortHeap \t \t \t \t" + h5);

			bw.close();
		} catch (IOException e) {
			System.out.println("Couldn't open file");
		}
		//writing the run times to the output file

		double i6 = runSortInsert(j6);
		double i7 = runSortInsert(j7);
		double i8 = runSortInsert(j8);

		double c6 = runSortComparable(j6);
		double c7 = runSortComparable(j7);
		double c8 = runSortComparable(j8);

		double b6 = runSortBinary(j6);
		double b7 = runSortBinary(j7);
		double b8 = runSortBinary(j8);

		double m6 = runSortMerge(j6);
		double m7 = runSortMerge(j7);
		double m8 = runSortMerge(j8);

		double h6 = runSortHeap(j6);
		double h7 = runSortHeap(j7);
		double h8 = runSortHeap(j8);
		//getting the time to run the extra three large arrays
/**
		try (FileWriter fw = new FileWriter("data/a2_analysis.txt", true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter out = new PrintWriter(bw)) {
			out.println("---------------------------------------------------------------");

			out.println("2^14 \t \t \t sortInsert \t \t \t" + i6);
			out.println("2^16 \t \t \t sortInsert \t \t \t" + i7);
			out.println("2^18 \t \t \t sortInsert \t \t \t" + i8);

			out.println("2^14 \t \t \t sortComparable \t \t" + c6);
			out.println("2^16 \t \t \t sortComparable \t \t" + c7);
			out.println("2^18 \t \t \t sortComparable \t \t" + c8);

			out.println("2^14 \t \t \t sortBinary \t \t \t" + b6);
			out.println("2^16 \t \t \t sortBinary \t \t \t" + b7);
			out.println("2^18 \t \t \t sortBinary \t \t \t" + b8);

			out.println("2^14 \t \t \t sortMerge \t \t \t \t" + m6);
			out.println("2^16 \t \t \t sortMerge \t \t \t \t" + m7);
			out.println("2^18 \t \t \t sortMerge \t \t \t \t" + m8);

			out.println("2^14 \t \t \t sortHeap \t \t \t \t" + h6);
			out.println("2^16 \t \t \t sortHeap \t \t \t \t" + h7);
			out.println("2^18 \t \t \t sortHeap \t \t \t \t" + h8);
			bw.close();
		} catch (IOException e) {
			System.out.println("Couldn't open file");
		}**/
		//printing the times to the output file

		/**
		StdDraw.setXscale(-Math.pow(2, 12) + 1000, Math.pow(2, 12) + 1000);
		StdDraw.setYscale(-10, 50);
		
		StdDraw.line(-25, 0, 10500, 0); // x-axis StdDraw.line(0, -25, 0,
		200); // y-axis
		 **/
		double[] x = { Math.pow(2, 4), Math.pow(2, 6), Math.pow(2, 8), Math.pow(2, 10), Math.pow(2, 12) };
		double[] y1 = { i1, i2, i3, i4, i5 };
		double[] y2 = { c1, c2, c3, c4, c5 };
		double[] y3 = { b1, b2, b3, b4, b5 };
		double[] y4 = { m1, m2, m3, m4, m5 };
		double[] y5 = { h1, h2, h3, h4, h5 };

		for (int i = 0; i < x.length - 1; i++) {
			// StdDraw.line(x[i], y1[i]*1000, x[i + 1], y1[i + 1]*1000);
			// sortInsert

			// StdDraw.line(x[i], y2[i]*1000, x[i + 1], y2[i + 1]*1000);
			// sortComparable

			// StdDraw.line(x[i], y3[i]*1000, x[i + 1], y3[i + 1]*1000);
			// sortBinary

			// StdDraw.line(x[i], y4[i]*1000, x[i + 1], y4[i + 1]*1000);
			// sortMerge

			// StdDraw.line(x[i], y5[i]*1000, x[i + 1], y5[i + 1]*1000);
			// sortHeap
		}
		//plotting the standard plots
		
		/**
		StdDraw.setXscale(-1, 6);
		StdDraw.setYscale(-1, 10);

		StdDraw.line(-25, 0, 10500, 0); // x-axis
		StdDraw.line(0, -25, 0, 200); // y-axis
		**/

		for (int i = 0; i < x.length - 1; i++) {
			//StdDraw.line(Math.log10(x[i]), Math.log10(y1[i] * 10000), Math.log10(x[i + 1]), Math.log10(y1[i + 1] * 10000));
			// sortInsert

			//StdDraw.line(Math.log10(x[i]), Math.log10(y2[i] * 10000), Math.log10(x[i + 1]), Math.log10(y2[i + 1] * 10000));
			// sortComparable

			//StdDraw.line(Math.log10(x[i]), Math.log10(y3[i] * 10000), Math.log10(x[i + 1]), Math.log10(y3[i + 1] * 10000));
			// sortBinary

			//StdDraw.line(Math.log10(x[i]), Math.log10(y4[i] * 10000), Math.log10(x[i + 1]), Math.log10(y4[i + 1] * 10000));
			// sortMerge

			//StdDraw.line(Math.log10(x[i]), Math.log10(y5[i] * 10000), Math.log10(x[i + 1]), Math.log10(y5[i + 1] * 10000));
			// sortHeap
		}
		//plotting the log log plots
	}

}
