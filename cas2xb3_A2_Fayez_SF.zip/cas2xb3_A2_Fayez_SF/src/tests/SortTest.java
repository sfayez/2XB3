/*
 * Student Information
 ----------------------------------
 Student Name: Fayez, Susan
 Student Number: 001404420
 Course Code: CS/SE 2XB3
 Lab Section: 03

 I attest that the following code being submitted is my own individual work
 */
package tests;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import sort.Job;
import sort.Merge;
import sort.Heap;
import sort.Insertion;

/**
 * Class that tests all of the sorting algorithms
 * 
 * @author Susan Fayez
 *
 */
public class SortTest {
	/**
	 * Initializing the global variables for the testing
	 */
	private Job[] j1;
	private Job[] j2;
	private Job[] j3;
	private Job[] j4;
	private Job[] j5;

	/**
	 * reads the Jobs from the input file and places them in the appropriate
	 * Job[] arrays before tests run
	 */
	@Before
	public void setup() {

		j1 = new Job[(int) Math.pow(2, 4)];
		j2 = new Job[(int) Math.pow(2, 6)];
		j3 = new Job[(int) Math.pow(2, 8)];
		j4 = new Job[(int) Math.pow(2, 10)];
		j5 = new Job[(int) Math.pow(2, 12)];

		try {
			Scanner read = new Scanner(new File("data/a2_in.txt"));
			String text = "";
			int count1 = 0;
			while (read.hasNext()) {
				String x = read.next();
				x = x.replaceAll("[\\{ \\} ,]", " ");
				text = text + x;
				count1++;
			}
			String[] words = text.split("\\s+");

			int count2 = 1;
			for (int i = 0; i < Math.pow(2, 4); i++) {
				j1[i] = new Job(words[count2], Integer.parseInt(words[count2 + 1]),
						Integer.parseInt(words[count2 + 2]));
				count2 = count2 + 3;
			}

			for (int i = 0; i < Math.pow(2, 6); i++) {
				j2[i] = new Job(words[count2], Integer.parseInt(words[count2 + 1]),
						Integer.parseInt(words[count2 + 2]));
				count2 = count2 + 3;
			}

			for (int i = 0; i < Math.pow(2, 8); i++) {
				j3[i] = new Job(words[count2], Integer.parseInt(words[count2 + 1]),
						Integer.parseInt(words[count2 + 2]));
				count2 = count2 + 3;
			}

			for (int i = 0; i < Math.pow(2, 10); i++) {
				j4[i] = new Job(words[count2], Integer.parseInt(words[count2 + 1]),
						Integer.parseInt(words[count2 + 2]));
				count2 = count2 + 3;
			}

			for (int i = 0; i < Math.pow(2, 12); i++) {
				j5[i] = new Job(words[count2], Integer.parseInt(words[count2 + 1]),
						Integer.parseInt(words[count2 + 2]));
				count2 = count2 + 3;
			}

			read.close();
		} catch (FileNotFoundException ex) {
			System.out.println("Couldn't open file");
		}
	}

	/**
	 * empties the Job[] arrays after tests run
	 */
	@After
	public void tearDown() {
		j1 = null;
		j2 = null;
		j3 = null;
		j4 = null;
		j5 = null;
	}

	/**
	 * applies sortInsert() to all arrays and asserts that each is sorted afterwards
	 */
	@Test
	public void testInsertSort() {
		Insertion.sortInsert(j1);
		for (int i = 1; i < j1.length; i++) {
			assertTrue(j1[i].compareTo(j1[i - 1]) >= 0);
		}
		Insertion.sortInsert(j2);
		for (int i = 1; i < j2.length; i++) {
			assertTrue(j2[i].compareTo(j2[i - 1]) >= 0);
		}
		Insertion.sortInsert(j3);
		for (int i = 1; i < j3.length; i++) {
			assertTrue(j3[i].compareTo(j3[i - 1]) >= 0);
		}
		Insertion.sortInsert(j4);
		for (int i = 1; i < j4.length; i++) {
			assertTrue(j4[i].compareTo(j4[i - 1]) >= 0);
		}
		Insertion.sortInsert(j5);
		for (int i = 1; i < j5.length; i++) {
			assertTrue(j5[i].compareTo(j5[i - 1]) >= 0);
		}
	}

	/**
	 * applies sortComparable() to all arrays and asserts that each is sorted afterwards
	 */
	@Test
	public void testComparable() {
		Insertion.sortComparable(j1, j1.length);
		for (int i = 1; i < j1.length; i++) {
			assertTrue(j1[i].compareTo(j1[i - 1]) >= 0);
		}
		Insertion.sortComparable(j2, j2.length);
		for (int i = 1; i < j2.length; i++) {
			assertTrue(j2[i].compareTo(j2[i - 1]) >= 0);
		}
		Insertion.sortComparable(j3, j3.length);
		for (int i = 1; i < j3.length; i++) {
			assertTrue(j3[i].compareTo(j3[i - 1]) >= 0);
		}
		Insertion.sortComparable(j4, j4.length);
		for (int i = 1; i < j4.length; i++) {
			assertTrue(j4[i].compareTo(j4[i - 1]) >= 0);
		}
		Insertion.sortComparable(j5, j5.length);
		for (int i = 1; i < j5.length; i++) {
			assertTrue(j5[i].compareTo(j5[i - 1]) >= 0);
		}
	}

	/**
	 * applies sortBinary() to all arrays and asserts that each is sorted afterwards
	 */
	@Test
	public void testBinary() {
		Insertion.sortBinary(j1, j1.length);
		for (int i = 1; i < j1.length; i++) {
			assertTrue(j1[i].compareTo(j1[i - 1]) >= 0);
		}
		Insertion.sortBinary(j2, j2.length);
		for (int i = 1; i < j2.length; i++) {
			assertTrue(j2[i].compareTo(j2[i - 1]) >= 0);
		}
		Insertion.sortBinary(j3, j3.length);
		for (int i = 1; i < j3.length; i++) {
			assertTrue(j3[i].compareTo(j3[i - 1]) >= 0);
		}
		Insertion.sortBinary(j4, j4.length);
		for (int i = 1; i < j4.length; i++) {
			assertTrue(j4[i].compareTo(j4[i - 1]) >= 0);
		}
		Insertion.sortBinary(j5, j5.length);
		for (int i = 1; i < j5.length; i++) {
			assertTrue(j5[i].compareTo(j5[i - 1]) >= 0);
		}
	}

	/**
	 * applies sortMerge() to all arrays and asserts that each is sorted afterwards
	 */
	@Test
	public void testSortMerge() {
		Comparable[] js1 = Merge.sortMerge(j1, j1.length);
		for (int i = 1; i < js1.length; i++) {
			assertTrue(js1[i].compareTo(js1[i - 1]) >= 0);
		}
		Comparable[] js2 = Merge.sortMerge(j1, j1.length);
		for (int i = 1; i < js2.length; i++) {
			assertTrue(js2[i].compareTo(js2[i - 1]) >= 0);
		}
		Comparable[] js3 = Merge.sortMerge(j1, j1.length);
		for (int i = 1; i < js3.length; i++) {
			assertTrue(js3[i].compareTo(js3[i - 1]) >= 0);
		}
		Comparable[] js4 = Merge.sortMerge(j1, j1.length);
		for (int i = 1; i < js4.length; i++) {
			assertTrue(js4[i].compareTo(js4[i - 1]) >= 0);
		}
		Comparable[] js5 = Merge.sortMerge(j1, j1.length);
		for (int i = 1; i < js5.length; i++) {
			assertTrue(js5[i].compareTo(js5[i - 1]) >= 0);
		}
	}

	/**
	 * applies sortHeap() to all arrays and asserts that each is sorted afterwards
	 */
	@Test
	public void testSortHeap() {
		Heap.sortHeap(j1, j1.length);
		for (int i = 1; i < j1.length; i++) {
			assertTrue(j1[i].compareTo(j1[i - 1]) >= 0);
		}
		
		Heap.sortHeap(j2, j2.length);
		for (int i = 1; i < j2.length; i++) {
			assertTrue(j2[i].compareTo(j2[i - 1]) >= 0);
		}
		
		Heap.sortHeap(j3, j3.length);
		for (int i = 1; i < j3.length; i++) {
			assertTrue(j3[i].compareTo(j3[i - 1]) >= 0);
		}
		
		Heap.sortHeap(j4, j4.length);
		for (int i = 1; i < j4.length; i++) {
			assertTrue(j4[i].compareTo(j4[i - 1]) >= 0);
		}
		
		Heap.sortHeap(j5, j5.length);
		for (int i = 1; i < j5.length; i++) {
			assertTrue(j5[i].compareTo(j5[i - 1]) >= 0);
		}
	}

}
