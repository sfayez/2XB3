/*
 * Student Information
 ----------------------------------
 Student Name: Fayez, Susan
 Student Number: 001404420
 Course Code: CS/SE 2XB3
 Lab Section: 03

 I attest that the following code being submitted is my own individual work
 */
package sort;
/**
 * Class that implements heap sort for Comparable[] arrays
 * 
 * @author Susan Fayez
 *
 */
public class Heap {
	/**
	 * heap sort using Comparable
	 * 
	 * @param x
	 *            - the input array containing times of jobs that need to be
	 *            sorted.
	 * @param n
	 *            - the size of the input array
	 */
	public static void sortHeap(Comparable[] x, int n) {
		for (int k = n / 2; k >= 1; k--) {
			sink(x, k, n);
		}
		while (n > 1) {
			exch(x, 1, n--);
			sink(x, 1, n);
		}
	}

	/**
	 * sink method of heapsort
	 * 
	 * @param x
	 *            - the array we want to sink
	 * @param k
	 *            - the midpoint of the array
	 * @param n
	 *            - the length of the array
	 */
	private static void sink(Comparable[] x, int k, int n) {
		while (2 * k <= n) {
			int j = 2 * k;
			if (j < n && less(x, j, j + 1)) {
				j++;
			}
			if (!less(x, k, j)) {
				break;
			}
			exch(x, k, j);
			k = j;
		}
	}

	/**
	 * method compares the values of elements in a comparable array
	 * 
	 * @param x
	 *            - the array containing the values to be compared
	 * @param i
	 *            - the index above the first compare point
	 * @param j
	 *            - the index above the second compare point
	 * @return true if the first is less than the second, false otherwise
	 */
	private static boolean less(Comparable[] x, int i, int j) {
		return x[i - 1].compareTo(x[j - 1]) < 0;
	}

	/**
	 * method exchanges two elements in a comparable array
	 * 
	 * @param x
	 *            - the comparable array for which the values will be swapped
	 * @param i
	 *            - the index above the first value in the array
	 * @param j
	 *            - the index above the second value in the array
	 */
	private static void exch(Object[] x, int i, int j) {
		Object swap = x[i - 1];
		x[i - 1] = x[j - 1];
		x[j - 1] = swap;
	}
}
