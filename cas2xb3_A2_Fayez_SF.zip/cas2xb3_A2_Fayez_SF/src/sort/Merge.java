/*
 * Student Information
 ----------------------------------
 Student Name: Fayez, Susan
 Student Number: 001404420
 Course Code: CS/SE 2XB3
 Lab Section: 03

 I attest that the following code being submitted is my own individual work
 */
package sort;

/**
 * Class that implements mergesort
 * 
 * @author Susan Fayez
 *
 */
public class Merge {
	/**
	 * merge sort using Comparable
	 * 
	 * @param x
	 *            - the input array containing times of jobs that need to be
	 *            sorted.
	 * @param n
	 *            - the size of the input array
	 *            
	 * @return - the array of jobs sorted by processing time
	 */
	public static Comparable[] sortMerge(Comparable[] x, int n) {
		if (n <= 1) {
			return x;
		}
		Comparable[] a = new Comparable[n / 2];
		Comparable[] b = new Comparable[n - n / 2];
		for (int i = 0; i < a.length; i++) {
			a[i] = x[i];
		}
		for (int i = 0; i < b.length; i++) {
			b[i] = x[i + n / 2];
		}
		return merge(sortMerge(a, a.length), sortMerge(b, b.length));
	}

	/**
	 * Method to merge two arrays in mergesort
	 * 
	 * @param a
	 *            - the first half of the array
	 * @param b
	 *            - the second half of the array
	 *            
	 * @return - the merged array
	 */

	private static Comparable[] merge(Comparable[] a, Comparable[] b) {
		Comparable[] c = new Comparable[a.length + b.length];
		int i = 0;
		int j = 0;
		for (int k = 0; k < c.length; k++) {
			if (i >= a.length) {
				c[k] = b[j++];
			} else if (j >= b.length) {
				c[k] = a[i++];
			} else if (((Job) a[i]).compareTo((Job) b[j]) <= 0) {
				c[k] = a[i++];
			} else {
				c[k] = b[j++];
			}
		}
		return c;
	}

}
