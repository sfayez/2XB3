package sort;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import sort.Insertion;

public class Job implements Comparable<Job>{
	private String jobID;
	private int processingTime;
	private int arrivalTime;
	
	public Job(String id, int pTime, int aTime)
	{
		this.jobID = id;
		this.processingTime = pTime;
		this.arrivalTime = aTime;
	}
	
	public int getProcessingTime()
	{
		return this.processingTime;
	}
	public void setProcessingTime(int t)
	{
		this.processingTime = t;
	}
	
	public int getArrivalTime()
	{
		return this.arrivalTime;
	}
	public void setArrivalTime(int t)
	{
		this.arrivalTime = t;
	}
	
	public String getJobID()
	{
		
		return this.jobID;
	}
	public void setJobID(String id)
	{
		this.jobID = id;
	}
	
	@Override
	public int compareTo(Job other)
	{
		if(this.processingTime > other.getProcessingTime()){
			return 1;
		}
		if(this.processingTime < other.getProcessingTime()){
			return -1;
		}
		else{
			return 0;
		}
	}
	
	
	public String toString()
	{
		return this.jobID + ", " + this.processingTime+ ", " + this.arrivalTime;
	}
	
}
