/*
 * Student Information
 ----------------------------------
 Student Name: Fayez, Susan
 Student Number: 001404420
 Course Code: CS/SE 2XB3
 Lab Section: 03

 I attest that the following code being submitted is my own individual work
 */
package sort;
/**
 * Class that implements regular insertion sort, insertion sort using Comparable(),
 * and insertion sort using binary search
 * 
 * @author Susan Fayez
 *
 */
public class Insertion {
	/**
	 * regular insertion sort
	 * 
	 * @param x
	 *            - the input array containing processing times of jobs that
	 *            need to be sorted.
	 */
	public static void sortInsert(Job[] x) {
		int n = x.length;
		for (int i = 0; i < n; i++) {
			for (int j = i; j > 0 && x[j].getProcessingTime() < x[j - 1].getProcessingTime(); j--) {
				Job swap = x[j];
				x[j] = x[j - 1];
				x[j - 1] = swap;
			}

		}

	}

	/**
	 * insertion sort using Comparable
	 * 
	 * @param x
	 *            - the input array containing times of jobs that need to be
	 *            sorted.
	 * @param n
	 *            - the size of the input array
	 */
	public static void sortComparable(Comparable[] x, int n) {
		for (int i = 0; i < n; i++) {
			for (int j = i; j > 0 && x[j].compareTo(x[j - 1]) < 0; j--) {
				Comparable swap = x[j];
				x[j] = x[j - 1];
				x[j - 1] = swap;
			}
		}
	}

	/**
	 * optimized insertion sort
	 * 
	 * @param x
	 *            - the input array containing times of jobs that need to be
	 *            sorted.
	 * @param n
	 *            - the size of the input array
	 */
	public static void sortBinary(Comparable[] x, int n) {
		int s;
		Comparable t;

		for (int i = 1; i < n; i++) {
			s = searchBinary(x, 0, i, x[i]);
			t = x[i];
			for (int j = i - 1; j >= s; j--)
				x[j + 1] = x[j];
			x[s] = t;
		}
	}

	/**
	 * method finds the point at which to insert for insertion sort
	 * 
	 * @param x
	 *            - the array for which to find the insertion point
	 * @param l
	 *            - the start index of the search
	 * @param h
	 *            - the end index of the search
	 * @param k
	 *            - the element to be inserted
	 *            
	 * @return - the index of the insertion point
	 */
	public static int searchBinary(Comparable x[], int l, int h, Comparable k) {
		int m;

		if (l == h) {
			return l;
		}
		m = l + ((h - l) / 2);

		if (k.compareTo(x[m]) == 1) {
			return searchBinary(x, m + 1, h, k);
		} else if (k.compareTo(x[m]) <= 0) {
			return searchBinary(x, l, m, k);
		}
		return m;
	}
}
